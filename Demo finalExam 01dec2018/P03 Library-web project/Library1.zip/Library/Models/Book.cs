﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Library.Models
{
    public class Book
    {
        public Book()
        {
            this.Price = 1;
        }
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Author { get; set; }

        public decimal Price { get; set; }
    }
}
